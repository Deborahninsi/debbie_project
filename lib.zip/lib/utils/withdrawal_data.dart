
import '../models/withdraw.dart';

class WithdrawalData {
  static final List<Withdrawal> withdrawals = [];
}
